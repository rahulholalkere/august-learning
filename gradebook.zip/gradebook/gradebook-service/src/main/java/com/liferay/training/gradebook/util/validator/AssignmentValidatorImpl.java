package com.liferay.training.gradebook.util.validator;

import com.liferay.training.gradebook.validator.AssignmentValidator;

import org.osgi.service.component.annotations.Component;

/**
 * 
 * @author hgrahul
 * Implementation Logic For Assignment Validation Purpose
 * 
 */
@Component(immediate = true, service = AssignmentValidator.class)
public class AssignmentValidatorImpl implements AssignmentValidator{
	
}
